var _fade_not_gamma_correct_8ino =
[
    [ "loop", "_fade_not_gamma_correct_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "_fade_not_gamma_correct_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "leds", "_fade_not_gamma_correct_8ino.html#a4f31086c758731a8536dc68e3bc7283f", null ]
];